# The Sovereign Path

**Australia's Premier Horoscope & Life Advice Platform**

Built by Bennett Russell Maynard-Brown — professional astrologer with 30+ years of experience.

---

## Files

```
sovereign-path/
├── index.html          ← Public website (homepage)
├── admin.html          ← Admin portal (private)
├── css/
│   ├── style.css       ← Main styles
│   └── admin.css       ← Admin styles
└── js/
    ├── horoscopes.js   ← All 12 sign readings
    └── app.js          ← Site interactivity
```

---

## Deploy to GitHub Pages (Free Hosting)

1. Create a free account at [github.com](https://github.com)
2. Click **New Repository** → name it `thesovereignpath` (or any name)
3. Upload all files in this folder (drag & drop in the GitHub interface)
4. Go to **Settings → Pages → Source → Deploy from branch → main → / (root)**
5. Your site will be live at: `https://yourusername.github.io/thesovereignpath/`

---

## First-Time Admin Setup (do this before going live)

1. Open `admin.html` in your browser (or go to `yoursite.com/admin.html`)
2. Default password: **sovereign2024** — change it immediately in Settings
3. Go to **Bank Details** → enter your BSB, account number, account name
4. Go to **Notifications** → enter your email address for payment alerts
5. Go to **Compose & Send → EmailJS Setup** → connect your free EmailJS account

---

## Setting Up Email Notifications (Free — EmailJS)

EmailJS lets you receive email alerts when customers subscribe, and send readings directly from the admin dashboard — **no server required**.

### Steps:
1. Go to [emailjs.com](https://www.emailjs.com) and create a free account
2. Add a **Service** (connect your Gmail or other email)
3. Create **Template 1** (for readings) with these variables:
   - `{{to_name}}`, `{{to_email}}`, `{{subject}}`, `{{message}}`, `{{from_name}}`
4. Create **Template 2** (for notifications to you) with the same variables
5. Copy your **Public Key**, **Service ID**, and both **Template IDs**
6. Paste them into **Admin → Compose & Send → EmailJS Setup**
7. Enter your email in **Admin → Notifications**

Free plan: 200 emails/month. Upgrade at emailjs.com for more.

---

## How the Payment Flow Works

1. Customer selects a plan on the site and fills in their details
2. They are shown your bank transfer details (BSB + account number)
3. **You receive an instant email notification** with their name, plan, and birth details
4. Once their transfer arrives in your bank, log into `admin.html`
5. Find them under **Pending Payment** → click **Activate**
6. Go to **Compose & Send** → write their first reading → send it

---

## Security Hash

`48831f24d7768595a89793910c55f1f9e2e60475e6389768551722881a7a101d`

---

*Philosophy: Simple & Smart. The Sovereign: Mowy.*
