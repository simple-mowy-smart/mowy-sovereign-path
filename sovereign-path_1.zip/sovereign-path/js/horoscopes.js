// THE SOVEREIGN PATH — Horoscope Data
// Written by Bennett Russell Maynard-Brown
// All 12 zodiac signs — daily template readings

const HOROSCOPES = {
  aries: {
    symbol: '♈',
    name: 'Aries',
    dates: 'March 21 – April 19',
    element: 'Fire',
    ruler: 'Mars',
    colour: '#c9a84c',
    tagline: 'The Pioneer',
    today: {
      overall: `The energy of Mars, your ruling planet, is surging forward today — and so should you. This is not a day for hesitation. A decision you have been circling for weeks is ready to be made, and the stars are aligned in your favour. Trust the fire in your chest; it is not recklessness, it is clarity.`,
      love: `In matters of the heart, your directness is your greatest gift today. If there is something unsaid between you and a loved one, say it. Aries energy does not thrive in ambiguity, and neither do your relationships.`,
      career: `A bold move in your professional life is supported by today's planetary alignment. Whether it is asking for what you deserve or stepping into a leadership role you have been avoiding, the cosmos says: now.`,
      wellness: `Channel your abundant physical energy into movement. A morning run, a swim, or even a brisk walk will clear the mental fog and sharpen your instincts for the day ahead.`,
      lucky_number: '9',
      lucky_colour: 'Crimson',
      affirmation: 'I move forward with courage and clarity. My fire lights the way.'
    }
  },
  taurus: {
    symbol: '♉',
    name: 'Taurus',
    dates: 'April 20 – May 20',
    element: 'Earth',
    ruler: 'Venus',
    colour: '#8fbc8f',
    tagline: 'The Steadfast',
    today: {
      overall: `Venus, your ruling planet, is casting a warm and generous light over your day. There is a quiet abundance available to you right now — not the dramatic windfall, but the steady, reliable kind that builds into something lasting. Slow down enough to receive it.`,
      love: `Your sensual nature is heightened today. Whether you are in a relationship or seeking one, this is a day to invest in beauty, comfort, and genuine connection. Cook a beautiful meal. Light a candle. Create the environment that love grows in.`,
      career: `Patience is your superpower, and today it pays dividends. A project you have been tending carefully is showing signs of real progress. Do not rush the harvest — but do take a moment to acknowledge how far you have come.`,
      wellness: `Your body is speaking to you today. Listen to it. Rest if you need rest. Nourish yourself with real food and time in nature. The earth is your element — spend time in it.`,
      lucky_number: '6',
      lucky_colour: 'Forest Green',
      affirmation: 'I am rooted, abundant, and open to all that is good.'
    }
  },
  gemini: {
    symbol: '♊',
    name: 'Gemini',
    dates: 'May 21 – June 20',
    element: 'Air',
    ruler: 'Mercury',
    colour: '#87ceeb',
    tagline: 'The Communicator',
    today: {
      overall: `Mercury, your ruling planet, is sharp and swift today — and so is your mind. Ideas are arriving faster than you can write them down. Do not dismiss the ones that seem too ambitious. The most brilliant Gemini insights often arrive dressed as wild notions.`,
      love: `Communication is the currency of your relationships, and today you have plenty to spend. A conversation you have been putting off will go better than expected. Your wit and warmth are irresistible right now.`,
      career: `Your ability to see multiple perspectives simultaneously is your greatest professional asset. Today, use it. A problem that has stumped others will yield to your lateral thinking. Speak up in meetings — your ideas are worth hearing.`,
      wellness: `Your nervous system needs grounding today. Between the mental activity and the social energy, carve out twenty minutes of genuine stillness. Breathe. Your mind will thank you.`,
      lucky_number: '5',
      lucky_colour: 'Sky Blue',
      affirmation: 'My mind is clear, my words are true, and my connections are meaningful.'
    }
  },
  cancer: {
    symbol: '♋',
    name: 'Cancer',
    dates: 'June 21 – July 22',
    element: 'Water',
    ruler: 'The Moon',
    colour: '#b0c4de',
    tagline: 'The Nurturer',
    today: {
      overall: `The Moon, your ruling body, is moving through a phase of emotional clarity today. What has felt murky or confusing in recent weeks is beginning to crystallise. Trust what you feel — your intuition is not anxiety in disguise. It is ancient wisdom speaking.`,
      love: `Your capacity for deep, unconditional love is your greatest gift. Today, let yourself receive as well as give. Allow someone who loves you to care for you. You do not always have to be the strong one.`,
      career: `Your emotional intelligence is an asset in any professional environment, and today it is particularly powerful. A colleague or client needs to feel heard — and you are perfectly positioned to offer that. This act of genuine care will open doors.`,
      wellness: `Water is your element and your healer. A bath, a swim, or even sitting near the ocean or a river will restore your energy today. Honour your need for emotional safety and quiet.`,
      lucky_number: '2',
      lucky_colour: 'Silver',
      affirmation: 'I trust my feelings. I am safe to love and be loved deeply.'
    }
  },
  leo: {
    symbol: '♌',
    name: 'Leo',
    dates: 'July 23 – August 22',
    element: 'Fire',
    ruler: 'The Sun',
    colour: '#ffd700',
    tagline: 'The Sovereign',
    today: {
      overall: `The Sun, your ruling star, is shining its full light on you today. This is your natural state — radiant, generous, and magnetic. Do not dim yourself for anyone. The world needs your warmth, your courage, and your unshakeable belief that life is meant to be lived fully.`,
      love: `Romance is in the air for Leo today. Whether you are deepening an existing bond or attracting new connection, your natural charisma is operating at full power. Lead with your heart — it has never steered you wrong.`,
      career: `Leadership opportunities are presenting themselves. Step forward. You were born to inspire others, and today the stage is yours. Speak with conviction, act with generosity, and watch others rise to meet your vision.`,
      wellness: `Your energy is high, but remember that even the Sun sets. Balance your natural exuberance with genuine rest. Play, create, and move your body — then sleep like the royalty you are.`,
      lucky_number: '1',
      lucky_colour: 'Gold',
      affirmation: 'I shine without apology. My light lifts everyone around me.'
    }
  },
  virgo: {
    symbol: '♍',
    name: 'Virgo',
    dates: 'August 23 – September 22',
    element: 'Earth',
    ruler: 'Mercury',
    colour: '#98fb98',
    tagline: 'The Craftsman',
    today: {
      overall: `Your analytical mind is your greatest tool, and today it is operating with exceptional precision. A complex situation that has required careful thought is ready for your verdict. Trust your analysis — you have done the work, and your conclusions are sound.`,
      love: `You show love through acts of service, and today that quality is deeply appreciated by those closest to you. Do not underestimate the power of the small, thoughtful gesture. It means more than grand declarations.`,
      career: `Detail-oriented work is favoured today. If you have a project that requires precision, focus, or careful editing — this is your moment. Your standards are high, and today the results will match them.`,
      wellness: `Your body responds well to routine and nourishment. Today, honour that. A clean, simple meal, a walk in fresh air, and an early night will restore your system beautifully.`,
      lucky_number: '4',
      lucky_colour: 'Sage Green',
      affirmation: 'I trust my discernment. My attention to detail creates excellence.'
    }
  },
  libra: {
    symbol: '♎',
    name: 'Libra',
    dates: 'September 23 – October 22',
    element: 'Air',
    ruler: 'Venus',
    colour: '#dda0dd',
    tagline: 'The Harmonist',
    today: {
      overall: `Venus is blessing your day with beauty, balance, and the possibility of genuine harmony. You have been navigating a tension between two paths — and today, the right choice becomes clear. It is the one that honours both your needs and your values simultaneously.`,
      love: `Your natural gift for creating harmony makes you a deeply sought-after partner and friend. Today, use that gift consciously. Where can you bring peace? Where can you build a bridge? Your relationships will flourish.`,
      career: `Collaboration is your strength, and today a partnership opportunity presents itself. Approach it with your characteristic fairness and grace. The right alliance will multiply your impact significantly.`,
      wellness: `Balance is not just your life philosophy — it is your physical need. Today, find equilibrium between activity and rest, between social engagement and solitude. Beauty in your environment also nourishes you.`,
      lucky_number: '7',
      lucky_colour: 'Rose Pink',
      affirmation: 'I create harmony within myself, and it radiates into every relationship.'
    }
  },
  scorpio: {
    symbol: '♏',
    name: 'Scorpio',
    dates: 'October 23 – November 21',
    element: 'Water',
    ruler: 'Pluto & Mars',
    colour: '#8b0000',
    tagline: 'The Transformer',
    today: {
      overall: `Pluto, your ruling planet, is stirring the depths today — and you, more than any other sign, know how to navigate the deep. Something is transforming beneath the surface of your life. Do not resist it. The most powerful growth always happens in the dark, before the light.`,
      love: `Your intensity is your greatest gift in love, and today it is magnetic. Someone in your orbit is drawn to your depth and authenticity. Let them in — not all the way, not yet, but enough to begin something real.`,
      career: `Your ability to see beneath the surface of any situation gives you a strategic advantage today. You notice what others miss. Use this insight wisely — not to manipulate, but to navigate with extraordinary precision.`,
      wellness: `Emotional release is healing for Scorpio. Whether through journaling, a long conversation with a trusted person, or simply allowing yourself to feel what you have been suppressing — let it move through you. Transformation requires release.`,
      lucky_number: '8',
      lucky_colour: 'Deep Burgundy',
      affirmation: 'I embrace transformation. My depth is my power and my gift.'
    }
  },
  sagittarius: {
    symbol: '♐',
    name: 'Sagittarius',
    dates: 'November 22 – December 21',
    element: 'Fire',
    ruler: 'Jupiter',
    colour: '#ff8c00',
    tagline: 'The Seeker',
    today: {
      overall: `Jupiter, your ruling planet, is expanding your horizon today — literally and metaphorically. An opportunity to learn, travel, or broaden your perspective is presenting itself. Say yes to it. Your greatest growth has always come from the journey, not the destination.`,
      love: `Your honesty and enthusiasm are irresistible today. Do not overthink connection — your natural warmth and sense of adventure are more than enough. Share your vision for the future with someone who matters to you.`,
      career: `Big-picture thinking is your forte, and today a long-range vision you have been developing is ready to be shared. Do not wait for perfect conditions. The archer who never releases the arrow never hits the mark.`,
      wellness: `Movement and freedom are your medicine. Get outside, explore somewhere new, or simply change your routine in a meaningful way. Your spirit expands when your body is in motion.`,
      lucky_number: '3',
      lucky_colour: 'Burnt Orange',
      affirmation: 'I expand into possibility. Every horizon is an invitation.'
    }
  },
  capricorn: {
    symbol: '♑',
    name: 'Capricorn',
    dates: 'December 22 – January 19',
    element: 'Earth',
    ruler: 'Saturn',
    colour: '#708090',
    tagline: 'The Architect',
    today: {
      overall: `Saturn, your ruling planet, rewards discipline with durability — and today you are seeing the results of your long-term efforts. Something you have been building, patiently and methodically, is showing its first signs of real, lasting success. This is not luck. This is mastery.`,
      love: `You love with loyalty and depth, and today that quality is recognised and deeply valued. Allow yourself to be seen — not just as the capable, reliable one, but as the person who also needs warmth, tenderness, and appreciation.`,
      career: `Your reputation for integrity and excellence opens a significant door today. A professional opportunity that aligns with your long-term goals is within reach. Approach it with your characteristic thoroughness and quiet confidence.`,
      wellness: `Your body is a long-term investment, and today is a good day to honour that. Structure your day with intention — good food, purposeful movement, and adequate rest. You build empires; start with your own health.`,
      lucky_number: '10',
      lucky_colour: 'Charcoal',
      affirmation: 'I build with patience and purpose. My discipline creates my freedom.'
    }
  },
  aquarius: {
    symbol: '♒',
    name: 'Aquarius',
    dates: 'January 20 – February 18',
    element: 'Air',
    ruler: 'Uranus & Saturn',
    colour: '#00ced1',
    tagline: 'The Visionary',
    today: {
      overall: `Uranus, your ruling planet, is sparking innovation and originality today. An idea that seems unconventional — perhaps even radical — deserves your serious attention. The future you envision is not a fantasy. It is a blueprint. Begin drafting it.`,
      love: `Your uniqueness is your most attractive quality, and today someone sees it clearly. Do not conform to what you think love is supposed to look like. Your most meaningful connections are built on intellectual resonance and mutual respect for freedom.`,
      career: `Your ability to think ahead of the curve is invaluable today. A problem that has stumped conventional thinkers will yield to your lateral, future-oriented approach. Share your vision — even if it makes people uncomfortable.`,
      wellness: `Your mind runs fast and your nervous system needs support. Grounding practices — time in nature, breathwork, or simply unplugging from technology for an hour — will restore your equilibrium.`,
      lucky_number: '11',
      lucky_colour: 'Electric Blue',
      affirmation: 'I think freely and love freely. My vision serves the world.'
    }
  },
  pisces: {
    symbol: '♓',
    name: 'Pisces',
    dates: 'February 19 – March 20',
    element: 'Water',
    ruler: 'Neptune & Jupiter',
    colour: '#9370db',
    tagline: 'The Mystic',
    today: {
      overall: `Neptune, your ruling planet, is deepening your intuition and your connection to the unseen today. Pay attention to dreams, synchronicities, and the quiet knowing that arrives between thoughts. The universe is communicating with you in its most subtle and beautiful language.`,
      love: `Your capacity for empathy and unconditional love is extraordinary, and today it creates a moment of genuine, soul-level connection. Allow yourself to be fully present with someone you love. No distractions. Just presence.`,
      career: `Your creativity and imagination are your professional superpowers, and today they are operating at their peak. Any work that involves art, healing, writing, music, or vision will flow with unusual grace and beauty.`,
      wellness: `Water, music, and creative expression are your healers today. A long bath, an hour with your favourite music, or time spent creating something beautiful will restore your spirit completely.`,
      lucky_number: '12',
      lucky_colour: 'Violet',
      affirmation: 'I trust the flow of life. My sensitivity is my greatest strength.'
    }
  }
};
