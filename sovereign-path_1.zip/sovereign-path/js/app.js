// THE SOVEREIGN PATH — Main Application JS

// ── MOBILE MENU ──────────────────────────────────────────────
function toggleMenu() {
  const menu = document.getElementById('mobileMenu');
  menu.classList.toggle('open');
}

// ── SCROLL ANIMATIONS ────────────────────────────────────────
const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: 0.1 });
document.querySelectorAll('.fade-in').forEach(el => observer.observe(el));

// ── NAVBAR SCROLL ────────────────────────────────────────────
window.addEventListener('scroll', () => {
  document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 60);
});

// ── HOROSCOPE MODAL ──────────────────────────────────────────
function openHoroscope(sign) {
  const d = HOROSCOPES[sign];
  if (!d) return;
  const today = new Date().toLocaleDateString('en-AU', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
  document.getElementById('modalBody').innerHTML = `
    <div class="center" style="margin-bottom:1.5rem;">
      <div class="modal-sign-symbol">${d.symbol}</div>
      <span class="modal-tag">${d.tagline}</span>
      <h2>${d.name}</h2>
      <p class="muted">${d.dates} &nbsp;·&nbsp; ${d.element} Sign &nbsp;·&nbsp; Ruled by ${d.ruler}</p>
      <p class="muted" style="font-size:0.75rem;">Reading for ${today}</p>
    </div>
    <p>${d.today.overall}</p>
    <div class="modal-section">
      <h4>♥ Love &amp; Relationships</h4>
      <p>${d.today.love}</p>
    </div>
    <div class="modal-section">
      <h4>✦ Career &amp; Purpose</h4>
      <p>${d.today.career}</p>
    </div>
    <div class="modal-section">
      <h4>🌿 Wellness</h4>
      <p>${d.today.wellness}</p>
    </div>
    <div class="modal-section" style="background:rgba(201,168,76,0.06);padding:1.2rem;border:1px solid var(--border);margin-top:1.5rem;">
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;text-align:center;">
        <div><strong class="gold" style="font-size:0.7rem;letter-spacing:0.1em;text-transform:uppercase;">Lucky Number</strong><br><span style="font-size:1.4rem;font-family:'Cormorant Garamond',serif;">${d.today.lucky_number}</span></div>
        <div><strong class="gold" style="font-size:0.7rem;letter-spacing:0.1em;text-transform:uppercase;">Lucky Colour</strong><br><span style="font-size:0.95rem;">${d.today.lucky_colour}</span></div>
        <div><strong class="gold" style="font-size:0.7rem;letter-spacing:0.1em;text-transform:uppercase;">Affirmation</strong><br><span style="font-size:0.78rem;font-style:italic;">${d.today.affirmation}</span></div>
      </div>
    </div>
    <div class="modal-section center">
      <p style="font-size:0.85rem;color:var(--muted);">This is your daily public forecast. For a full personalised reading written specifically for your natal chart, subscribe to Sovereign Insights.</p>
      <a href="#subscribe" class="btn btn-gold" onclick="closeHoroscope()" style="margin-top:0.5rem;">Get My Personal Reading</a>
    </div>
  `;
  document.getElementById('horoscopeModal').classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeHoroscope() {
  document.getElementById('horoscopeModal').classList.remove('active');
  document.body.style.overflow = '';
}

function closeModal(e) {
  if (e.target === document.getElementById('horoscopeModal')) closeHoroscope();
}

// ── BIRTH CHART CALCULATOR ───────────────────────────────────
const ZODIAC_SIGNS = [
  { name:'Aries', symbol:'♈', start:[3,21], end:[4,19] },
  { name:'Taurus', symbol:'♉', start:[4,20], end:[5,20] },
  { name:'Gemini', symbol:'♊', start:[5,21], end:[6,20] },
  { name:'Cancer', symbol:'♋', start:[6,21], end:[7,22] },
  { name:'Leo', symbol:'♌', start:[7,23], end:[8,22] },
  { name:'Virgo', symbol:'♍', start:[8,23], end:[9,22] },
  { name:'Libra', symbol:'♎', start:[9,23], end:[10,22] },
  { name:'Scorpio', symbol:'♏', start:[10,23], end:[11,21] },
  { name:'Sagittarius', symbol:'♐', start:[11,22], end:[12,21] },
  { name:'Capricorn', symbol:'♑', start:[12,22], end:[1,19] },
  { name:'Aquarius', symbol:'♒', start:[1,20], end:[2,18] },
  { name:'Pisces', symbol:'♓', start:[2,19], end:[3,20] }
];

function getSunSign(dob) {
  const d = new Date(dob); const m = d.getMonth()+1; const day = d.getDate();
  for (const s of ZODIAC_SIGNS) {
    const [sm,sd] = s.start; const [em,ed] = s.end;
    if (sm <= em) { if ((m===sm&&day>=sd)||(m===em&&day<=ed)||(m>sm&&m<em)) return s; }
    else { if ((m===sm&&day>=sd)||m>sm||(m===em&&day<=ed)||m<em) return s; }
  }
  return ZODIAC_SIGNS[0];
}

const MOON_SIGNS   = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
const MOON_SYMBOLS = ['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓'];
const PLANETS      = ['Mercury','Venus','Mars','Jupiter','Saturn','Uranus','Neptune'];
const PLANET_GLYPHS= ['☿','♀','♂','♃','♄','⛢','♆'];
const HOUSES       = ['1st','2nd','3rd','4th','5th','6th','7th','8th','9th','10th','11th','12th'];

function seededRand(seed) {
  let x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function calculateChart() {
  const name = document.getElementById('bc-name').value.trim();
  const dob  = document.getElementById('bc-dob').value;
  const tob  = document.getElementById('bc-tob').value;
  const pob  = document.getElementById('bc-pob').value.trim();
  if (!name || !dob) { showToast('Please enter your name and date of birth.'); return; }

  const sun = getSunSign(dob);
  const seed = new Date(dob).getTime() / 1000000;
  const moonIdx    = Math.floor(seededRand(seed * 3.7) * 12);
  const risingIdx  = Math.floor(seededRand(seed * 7.3 + (tob ? parseInt(tob.replace(':','')) : 0)) * 12);

  let planetsHTML = `
    <div class="planet-item"><strong>☀ Sun</strong>${sun.symbol} ${sun.name}</div>
    <div class="planet-item"><strong>☽ Moon</strong>${MOON_SYMBOLS[moonIdx]} ${MOON_SIGNS[moonIdx]}</div>
    <div class="planet-item"><strong>↑ Rising</strong>${MOON_SYMBOLS[risingIdx]} ${MOON_SIGNS[risingIdx]}</div>
  `;
  PLANETS.forEach((p,i) => {
    const si = Math.floor(seededRand(seed * (i+2.1) * 1.9) * 12);
    const hi = Math.floor(seededRand(seed * (i+3.3) * 2.1) * 12);
    planetsHTML += `<div class="planet-item"><strong>${PLANET_GLYPHS[i]} ${p}</strong>${MOON_SYMBOLS[si]} ${MOON_SIGNS[si]} · ${HOUSES[hi]} House</div>`;
  });

  document.getElementById('chartName').textContent = `${name}'s Natal Chart`;
  document.getElementById('chartIntro').textContent =
    `Born under the ${sun.name} Sun${pob ? ' in ' + pob : ''}, your chart reveals a unique celestial blueprint. Your Moon in ${MOON_SIGNS[moonIdx]} shapes your emotional world, while your ${MOON_SIGNS[risingIdx]} Rising defines how the world first encounters you. Below are your planetary placements — the raw data of your cosmic identity.`;
  document.getElementById('chartPlanets').innerHTML = planetsHTML;
  const result = document.getElementById('chartResult');
  result.classList.add('active');
  result.scrollIntoView({ behavior:'smooth', block:'start' });
}

// ── SUBSCRIPTION MODAL ───────────────────────────────────────
let selectedPlan = '';
let selectedPrice = '';

function openSubscribeForm(plan, price) {
  selectedPlan  = plan;
  selectedPrice = price;
  document.getElementById('subPlanTitle').textContent = plan + ' Plan';
  document.getElementById('subPlanPrice').textContent = '$' + price + ' / month';
  document.getElementById('subFormStep1').style.display = 'block';
  document.getElementById('subFormStep2').style.display = 'none';
  document.getElementById('subscribeModal').classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeSubscribeModal(e) {
  if (!e || e.target === document.getElementById('subscribeModal')) {
    document.getElementById('subscribeModal').classList.remove('active');
    document.body.style.overflow = '';
  }
}

function submitSubscription() {
  const fname = document.getElementById('sub-fname').value.trim();
  const lname = document.getElementById('sub-lname').value.trim();
  const email = document.getElementById('sub-email').value.trim();
  const dob   = document.getElementById('sub-dob').value;
  const focus = document.getElementById('sub-focus').value;

  if (!fname || !lname || !email || !dob) {
    showToast('Please fill in all required fields.'); return;
  }

  // Save subscriber to localStorage
  const subscribers = JSON.parse(localStorage.getItem('tsp_subscribers') || '[]');
  const newSub = {
    id: Date.now(),
    name: fname + ' ' + lname,
    email,
    dob,
    tob:   document.getElementById('sub-tob').value,
    pob:   document.getElementById('sub-pob').value,
    focus,
    plan:  selectedPlan,
    price: selectedPrice,
    status: 'pending_payment',
    joined: new Date().toISOString(),
    readings: []
  };
  subscribers.push(newSub);
  localStorage.setItem('tsp_subscribers', JSON.stringify(subscribers));

  // ── FIRE NOTIFICATION EMAIL ──────────────────────────────
  fireNotificationEmail(newSub);

  // Load bank details
  const bankDetails = JSON.parse(localStorage.getItem('tsp_bank_details') || '{}');
  const bankHTML = bankDetails.account_name ? `
    <table class="bank-table">
      <tr><td>Account Name</td><td><strong>${bankDetails.account_name}</strong></td></tr>
      <tr><td>BSB</td><td><strong>${bankDetails.bsb || '—'}</strong></td></tr>
      <tr><td>Account Number</td><td><strong>${bankDetails.account_number || '—'}</strong></td></tr>
      <tr><td>Bank</td><td><strong>${bankDetails.bank_name || '—'}</strong></td></tr>
      ${bankDetails.payid ? `<tr><td>PayID</td><td><strong>${bankDetails.payid}</strong></td></tr>` : ''}
      <tr><td>Amount</td><td><strong>$${selectedPrice} AUD / month</strong></td></tr>
      <tr><td>Reference</td><td><strong>${fname} ${lname}</strong></td></tr>
    </table>
    ${bankDetails.instructions ? `<p style="font-size:0.82rem;color:var(--muted);margin-top:0.8rem;">Note: ${bankDetails.instructions}</p>` : ''}
  ` : `
    <div style="padding:1.5rem;border:1px solid var(--border);text-align:center;">
      <p style="color:var(--gold);">✦ Payment details will be emailed to <strong>${email}</strong> within 2 hours.</p>
      <p style="font-size:0.85rem;">Our team is notified of your subscription request and will send you the bank transfer details shortly.</p>
    </div>
  `;

  document.getElementById('bankDetailsDisplay').innerHTML = bankHTML;
  document.getElementById('subFormStep1').style.display = 'none';
  document.getElementById('subFormStep2').style.display = 'block';
}

// ── FIRE NOTIFICATION TO BENNETT ─────────────────────────────
function fireNotificationEmail(sub) {
  const notif = JSON.parse(localStorage.getItem('tsp_notifications') || '{}');
  const ejs   = JSON.parse(localStorage.getItem('tsp_emailjs') || '{}');

  if (!notif.email || !ejs.public_key || !ejs.service_id || !ejs.notif_template) return;

  // Init EmailJS if not already done
  try { emailjs.init({ publicKey: ejs.public_key }); } catch(e) {}

  const subject = `✦ New Subscriber — ${sub.name} (${sub.plan} Plan)`;
  const message =
`A new subscriber has signed up on The Sovereign Path:

Name:           ${sub.name}
Email:          ${sub.email}
Plan:           ${sub.plan} — $${sub.price}/mo
Date of Birth:  ${sub.dob || '—'}
Time of Birth:  ${sub.tob || '—'}
Place of Birth: ${sub.pob || '—'}
Focus:          ${sub.focus || '—'}
Status:         Pending Payment
Submitted:      ${new Date().toLocaleString('en-AU')}

Log in to your admin portal to activate once their bank transfer arrives.
${notif.custom_msg ? '\n' + notif.custom_msg : ''}`;

  const params = {
    to_email:  notif.email,
    to_name:   'Bennett',
    subject,
    message,
    from_name: 'The Sovereign Path'
  };

  try {
    emailjs.send(ejs.service_id, ejs.notif_template, params);
    if (notif.email_backup) {
      emailjs.send(ejs.service_id, ejs.notif_template, { ...params, to_email: notif.email_backup });
    }
  } catch(e) {}
}

// ── TOAST NOTIFICATION ───────────────────────────────────────
function showToast(msg, duration = 3500) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), duration);
}

// ── KEYBOARD ESC CLOSE ───────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeHoroscope();
    closeSubscribeModal();
  }
});
